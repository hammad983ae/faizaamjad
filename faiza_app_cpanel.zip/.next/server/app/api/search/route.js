var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/search/route.js")
R.c("server/chunks/[root-of-the-server]__dd32ceb9._.js")
R.c("server/chunks/[root-of-the-server]__e3b022f2._.js")
R.c("server/chunks/[root-of-the-server]__47624d9a._.js")
R.c("server/chunks/_next-internal_server_app_api_search_route_actions_4244da48.js")
R.m(62518)
module.exports=R.m(62518).exports
