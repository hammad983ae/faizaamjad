globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/804393fe99543ecd.js",
    "static/chunks/82abf2d65f5428ae.js",
    "static/chunks/10cbf02e6fc36465.js",
    "static/chunks/f2f58a7e93290fbb.js",
    "static/chunks/turbopack-e68405fd0122e9b0.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];