module.exports=[88774,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28main%29_contact_page_actions_4b063f94.js.map