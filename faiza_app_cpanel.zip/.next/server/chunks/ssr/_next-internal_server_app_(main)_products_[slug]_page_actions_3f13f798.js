module.exports=[65312,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28main%29_products_%5Bslug%5D_page_actions_3f13f798.js.map